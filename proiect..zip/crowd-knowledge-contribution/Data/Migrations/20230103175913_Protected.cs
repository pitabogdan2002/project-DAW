﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace crowd_knowledge_contribution.Data.Migrations
{
    public partial class Protected : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
